* Start up - how to do work after spring boot application starts up
* Intro - built in events
* Intro - custom event
* Generic event
* Conditional event
* Return event  
* Async event
* Transactional bound event