package com.example.events.async1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class MyApplicationEventListener2 implements ApplicationListener<ApplicationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(MyApplicationEventListener2.class);

    // watch the behavior of application event listens under async mode
    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        logger.info("All application event - {}", event.getClass().getSimpleName());
    }

}
