package com.example.events.async1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class MyApplicationEventListener {

    private static final Logger logger = LoggerFactory.getLogger(MyApplicationEventListener.class);

    // watch the behavior of application event listens under async mode
    @EventListener
    public void processEvent(ApplicationEvent event) {
        logger.info("Post start up application event - {}", event.getClass().getSimpleName());
    }

}
