package com.example.events.async1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.context.event.ApplicationEventMulticaster;
import org.springframework.context.event.EventListener;
import org.springframework.context.event.SimpleApplicationEventMulticaster;
import org.springframework.core.annotation.Order;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.scheduling.support.TaskUtils;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class AsyncEventApp {

    private static final Logger logger = LoggerFactory.getLogger(AsyncEventApp.class);

    public static void main(String[] args) {
        SpringApplication.run(AsyncEventApp.class, args);
    }

    // Handle events asynchronously
    // (not in the caller's thread)
    @Bean
    ApplicationEventMulticaster applicationEventMulticaster() {
        SimpleApplicationEventMulticaster eventMulticaster = new SimpleApplicationEventMulticaster();
        eventMulticaster.setTaskExecutor(new SimpleAsyncTaskExecutor());
        eventMulticaster.setErrorHandler(TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER);
        return eventMulticaster;
    }

    static class MyEvent1 {
    }

    static class MyEvent2 {
    }

    static class MyEvent3 {
    }

    @Component
    static class MyEventListener {

        @EventListener
        // for async event listener, Order doesn't matter
        @Order(1)
        void handle1(MyEvent1 event) {
            logger.info("handle event1 - handling my event '{}'", event);
        }

        @EventListener
        // for async event listener, Order doesn't matter
        @Order(10)
        void handle1Again(MyEvent1 event) {
            logger.info("handle event1Again - handling my event '{}'", event);
        }

        @EventListener
        void handle2(MyEvent2 event) {
            logger.info("handle event2 - handling my event '{}'", event);
        }

        @EventListener
        void handle3(MyEvent2 event) {
            logger.info("handle event3 - handling my event '{}'", event);
        }
    }

    @Component
    static class MyService {
        final ApplicationEventPublisher publisher;

        public MyService(ApplicationEventPublisher publisher) {
            this.publisher = publisher;
        }

        public void createEvents() {
            publisher.publishEvent(new MyEvent1());
            publisher.publishEvent(new MyEvent2());
            publisher.publishEvent(new MyEvent3());
        }
    }
    
    @Bean
    @Profile("!unit-test")
    public CommandLineRunner run(MyService service) {
        return args -> service.createEvents();
    }

}
