package com.example.events.returnevent;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class ReturnEventApp {

    private static final Logger logger = LoggerFactory.getLogger(ReturnEventApp.class);

    static class Event1 {
    }

    static class Event2 {
    }

    static class Event3 {
    }

    static class Event4 {
    }

    @Component
    static class MyEventListener {
        @EventListener
        void handleEvent1(Event1 event) {
            logger.info("handle event1 - handling event1");
        }

        @EventListener
        Event3 handleEvent2(Event2 event) {
            logger.info("handle event2 - handling event2");
            return new Event3();
        }

        @EventListener
        List<Event4> handleEvent3(Event3 event) {
            logger.info("handle event3 - handling event3");
            return Arrays.asList(new Event4(), new Event4());
        }

        @EventListener
        void handleEvent4(Event4 event) {
            logger.info("handle event4 - handling event4");
        }
    }

    @Component
    static class MyEventProducer {

        private final ApplicationEventPublisher publisher;

        public MyEventProducer(ApplicationEventPublisher publisher) {
            this.publisher = publisher;
        }

        public void createEvent() {
            publisher.publishEvent(new Event1());
            publisher.publishEvent(new Event2());
        }
    }

}
