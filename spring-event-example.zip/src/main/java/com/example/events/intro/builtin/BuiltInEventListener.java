package com.example.events.intro.builtin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class BuiltInEventListener implements ApplicationListener<ApplicationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(BuiltInEventListener.class);

    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        logger.info("All application event - {}", event.getClass().getSimpleName());
    }

}
