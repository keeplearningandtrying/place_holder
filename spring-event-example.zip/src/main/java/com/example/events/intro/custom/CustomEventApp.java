package com.example.events.intro.custom;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomEventApp {

}
