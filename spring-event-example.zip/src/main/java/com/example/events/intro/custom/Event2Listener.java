package com.example.events.intro.custom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
public class Event2Listener {

    private static final Logger logger = LoggerFactory.getLogger(Event2Listener.class);

    @EventListener
    // Order only works with sync listeners
    @Order(1)
    public void processEvent1(Event2 event) {
        logger.info("Handling Event2 - name {}", event.getA());
    }

    @EventListener
    @Order(2)
    public void processEvent2(Event2 event) {
        logger.info("Handling Event2 - name {}", event.getA());
    }

    @EventListener({ Event2.class, Event1.class })
    public void processEvent(Object event) {
        logger.info("Handling Event1 and Event2 again - name {}", event);
    }

}
