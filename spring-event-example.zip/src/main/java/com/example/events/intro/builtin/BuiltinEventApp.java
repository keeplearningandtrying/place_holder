package com.example.events.intro.builtin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.ApplicationEventMulticaster;
import org.springframework.context.event.SimpleApplicationEventMulticaster;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.scheduling.support.TaskUtils;

@SpringBootApplication
public class BuiltinEventApp {

    public static void main(String[] args) {
        SpringApplication springApplication = new SpringApplication(BuiltinEventApp.class);
        springApplication.addListeners(new BuiltInEventListener());
        springApplication.run(args);
    }

    /*
    @Bean
    @ConditionalOnProperty(name = "handling", havingValue = "async", matchIfMissing = false)
    ApplicationEventMulticaster applicationEventMulticaster() {
        SimpleApplicationEventMulticaster eventMulticaster = new SimpleApplicationEventMulticaster();
        eventMulticaster.setTaskExecutor(new SimpleAsyncTaskExecutor());
        eventMulticaster.setErrorHandler(TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER);
        return eventMulticaster;
    }
    */

}
