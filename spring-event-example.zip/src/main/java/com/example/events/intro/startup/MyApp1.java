package com.example.events.intro.startup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@SpringBootApplication
public class MyApp1 {
    
    private static final Logger logger = LoggerFactory.getLogger(MyApp1.class);

    public static void main(String[] args) {
        SpringApplication springApplication = new SpringApplication(MyApp1.class);
        springApplication.run(args);
    }

    @EventListener
    public void startUp(ApplicationReadyEvent event) {
        // Execute start up logic, such as load initial data
        logger.info("Hello World!");
    }

}
