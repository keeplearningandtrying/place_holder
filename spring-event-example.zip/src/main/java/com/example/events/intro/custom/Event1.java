package com.example.events.intro.custom;

import org.springframework.context.ApplicationEvent;

public class Event1 extends ApplicationEvent {

    private String name;

    Event1(Object source, String name) {
        super(source);
        this.name = name;
    }

    String getName() {
        return this.name;
    }

}
