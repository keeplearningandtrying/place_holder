package com.example.events.intro.custom;

public class Event2 {

    private String a;

    public Event2(String a) {
        this.a = a;
    }

    public String getA() {
        return a;
    }

}
