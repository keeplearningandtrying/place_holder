package com.example.events.intro.builtin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class MyApplicationEventListener {

    private static final Logger logger = LoggerFactory.getLogger(MyApplicationEventListener.class);

    @EventListener
    public void processEvent(ApplicationEvent event) {
        logger.info("Post start up application event - {}", event.getClass().getSimpleName());
    }

}
