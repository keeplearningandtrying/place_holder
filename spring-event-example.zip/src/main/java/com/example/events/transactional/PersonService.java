package com.example.events.transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class PersonService {

    private static final Logger logger = LoggerFactory.getLogger(PersonService.class);

    private ApplicationEventPublisher publisher;
    private final JdbcTemplate jdbcTemplate;

    public PersonService(JdbcTemplate jdbcTemplate, ApplicationEventPublisher publisher) {
        this.jdbcTemplate = jdbcTemplate;
        this.publisher = publisher;
    }

    @Transactional
    public void addPerson(String... persons) {
        publisher.publishEvent(new PersonAddedEvent("Person added event"));

        for (String person : persons) {
            logger.info("Adding person {} ", person);
            jdbcTemplate.update("insert into PERSON(FIRST_NAME) values (?)", person);
        }
    }

    @Transactional
    public void addPersonWithFinally(String... persons) {
        try {
            for (String person : persons) {
                logger.info("Booking {} in a seat", person);
                jdbcTemplate.update("insert into PERSON(FIRST_NAME) values (?)", person);
            }
        } finally {
            publisher.publishEvent(new PersonAddedEvent("Person added event"));
        }
    }

}
