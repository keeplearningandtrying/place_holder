package com.example.events.transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class PersonAddedEventListener {

    private static final Logger log = LoggerFactory.getLogger(PersonAddedEventListener.class);

    @EventListener
    public void handleEvent1(PersonAddedEvent event) {
        log.info("handEvent1 - @EventListener {}", event.getMessage());
    }

    @TransactionalEventListener(fallbackExecution = true)
    public void handleFallBackExecutionTrue(PersonAddedEvent event) {
        log.info("@TransactionEventListener fallbackExecution true {}", event.getMessage());
    }

    @TransactionalEventListener(fallbackExecution = false)
    public void handleFallBackExecutionFalse(PersonAddedEvent event) {
        log.info("@TransactionEventListener fallbackExecution false {}", event.getMessage());
    }

    // Transactional event listeners only work with thread-bound transactions
    // managed by a PlatformTransactionManager

    // Default - handle event after commit
    @TransactionalEventListener
    // @TransactionalEventListener(condition = "#event.amount >= 100")
    public void handleTransaction(PersonAddedEvent event) {
        log.info("@TransactionalEventListener all phases {}", event.getMessage());
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleTransactionCommit(PersonAddedEvent event) {
        log.info("@TransactionalEventListener after commit {}", event.getMessage());
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_ROLLBACK)
    public void handleTransactionRollback(PersonAddedEvent event) {
        log.info("@TransactionalEventListener after rollback {}", event.getMessage());
    }

    @EventListener
    public void handleEvent2(PersonAddedEvent event) {
        log.info("handEvent2 - @EventListener {}", event.getMessage());
    }

}
