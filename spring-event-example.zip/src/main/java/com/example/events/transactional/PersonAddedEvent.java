package com.example.events.transactional;

public class PersonAddedEvent {

    private final String message;

    public PersonAddedEvent(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
