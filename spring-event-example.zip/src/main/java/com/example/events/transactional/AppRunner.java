package com.example.events.transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
class AppRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(AppRunner.class);

    private final PersonService personService;

    public AppRunner(PersonService personService) {
        this.personService = personService;
    }

    @Override
    public void run(String... args) throws Exception {
        personService.addPerson("Mark", "Smith", "Allen");

        try {
            personService.addPerson("Steve", null);
        } catch (RuntimeException e) {
            logger.error("Exception: ", e);
        }

        try {
            personService.addPersonWithFinally("John", "Christopher");
        } catch (RuntimeException e) {
            logger.error("Exception:", e);
        }
    }

}
