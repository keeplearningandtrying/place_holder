package com.example.events.conditional;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class ConditionalEventApp {

    private static final Logger logger = LoggerFactory.getLogger(ConditionalEventApp.class);

    enum Type {
        CHECKING, SAVING
    }

    static class Account {
        private String name;
        private String number;

        public Account(String name, String number) {
            this.name = name;
            this.number = number;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        @Override
        public String toString() {
            return "name = " + name + "; number = " + number;
        }
    }

    static class AccountEvent {
        private Account account;

        public AccountEvent(Account account) {
            this.account = account;
        }

        public Account getAccount() {
            return account;
        }
    }

    static class AccountCreatedEvent extends AccountEvent {
        private Type type;

        public AccountCreatedEvent(Account account, Type type) {
            super(account);
            this.type = type;
        }

        @Override
        public String toString() {
            return "AccountCreatedEvent{" + "account ='" + getAccount() + '\'' + ",type ='" + type + '\'' + '}';
        }

        public Type getType() {
            return type;
        }
    }

    static class AccountActivatedEvent extends AccountEvent {
        private Date date;

        public AccountActivatedEvent(Account account, Date date) {
            super(account);
            this.date = date;
        }

        @Override
        public String toString() {
            return "AccountActivatedEvent{" + "account ='" + getAccount() + '\'' + ",date='" + date + '\'' + '}';
        }
    }

    static class DepositEvent extends AccountEvent {
        private int amount;

        public DepositEvent(Account account, int amount) {
            super(account);
            this.amount = amount;
        }

        public int getAmount() {
            return amount;
        }
    }

    @Component
    static class AccountEventListener {

        @EventListener(condition = "#event.type.name() == 'CHECKING'")
        public void handleHighPriorityReminders(AccountCreatedEvent event) {
            logger.info("handle checking account created events '{}'", event);
        }

        @EventListener
        public void handleReminderCreatedEvents(AccountCreatedEvent event) {
            logger.info("handle all account created events '{}'", event);
        }

        @EventListener({ AccountCreatedEvent.class, AccountActivatedEvent.class })
        public void handleAllEvents(AccountEvent event) {
            logger.info("handle all account events {}", event);
        }

        @EventListener(condition = "#event.amount >= 100")
        public void handleHighBids(DepositEvent event) {
            logger.info("handle deposit event of '{}'", event.amount);
        }
    }

    @Component
    static class AccountService {

        final ApplicationEventPublisher publisher;

        public AccountService(ApplicationEventPublisher publisher) {
            this.publisher = publisher;
        }

        public Account createAccount(String name, String number, Type type) {
            Account account = new Account(name, number);

            // Logic to create account

            AccountCreatedEvent event = new AccountCreatedEvent(account, type);
            logger.info("publish account created '{}' event'", event);
            publisher.publishEvent(event);
            return account;
        }

        public void activateAccount(Account account) {
            // logic to activate account

            AccountActivatedEvent event = new AccountActivatedEvent(account, new Date());
            logger.info("publish accocunt activated '{}' event", event);
            publisher.publishEvent(event);
        }

        public void depositToAccount(Account account, int amount) {
            // logic to deposit

            DepositEvent event = new DepositEvent(account, amount);
            logger.info("publish deposit '{}' event", event);
            publisher.publishEvent(event);
        }
    }

}
