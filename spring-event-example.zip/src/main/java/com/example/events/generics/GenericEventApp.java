package com.example.events.generics;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.core.ResolvableType;
import org.springframework.core.ResolvableTypeProvider;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class GenericEventApp {

    private static final Logger logger = LoggerFactory.getLogger(GenericEventApp.class);

    static class MyEvent<T> implements ResolvableTypeProvider {
        private T payload;

        public MyEvent(T payload) {
            this.payload = payload;
        }

        public T getPayload() {
            return payload;
        }

        @Override
        public ResolvableType getResolvableType() {
            return ResolvableType.forClassWithGenerics(getClass(), ResolvableType.forInstance(getPayload()));
        }
    }

    @Component
    static class MyEventHandler {
        @EventListener
        public void handleString(MyEvent<String> event) {
            logger.info("Event[{}] received. Payload={}", event.getClass().getSimpleName(), event.getPayload());
        }

        @EventListener
        public void handleLong(MyEvent<Long> event) {
            logger.info("Event[{}] received. Payload={}", event.getClass().getSimpleName(), event.getPayload());
        }
    }
    
    @Component
    static class MyEventProducer {
        final ApplicationEventPublisher publisher;

        public MyEventProducer(ApplicationEventPublisher publisher) {
            this.publisher = publisher;
        }

        public void createEvents() {
            publisher.publishEvent(new MyEvent<String>("Test event"));
            publisher.publishEvent(new MyEvent<Long>(100L));
        }
    }
    
    @Bean
    public CommandLineRunner run(MyEventProducer eventProducer) {
        return args -> eventProducer.createEvents();
    }

}