package com.example.events.async2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

@SpringBootApplication
@EnableAsync
public class AsyncEventApp {

    private static final Logger logger = LoggerFactory.getLogger(AsyncEventApp.class);

    public static void main(String[] args) {
        SpringApplication.run(AsyncEventApp.class, args);
    }

    static class MyEvent1 {
    }

    static class MyEvent2 {
    }

    static class MyEvent3 {
    }

    @Component
    static class MyEventListener {
        @EventListener
        void handle1(MyEvent1 event) {
            logger.info("handle event1 - handling my event '{}'", event);
        }

        @Async
        @EventListener
        void handle1Again(MyEvent1 event) {
            logger.info("handle event1Again async- handling my event '{}'", event);
        }

        @EventListener
        void handle2(MyEvent2 event) {
            logger.info("handle event2 - handling my event '{}'", event);
        }

        @Async
        @EventListener
        void handle3(MyEvent2 event) {
            logger.info("handle event3 async - handling my event '{}'", event);
        }
    }

    @Component
    static class MyService {
        final ApplicationEventPublisher publisher;

        public MyService(ApplicationEventPublisher publisher) {
            this.publisher = publisher;
        }

        public void createEvents() {
            publisher.publishEvent(new MyEvent1());
            publisher.publishEvent(new MyEvent2());
            publisher.publishEvent(new MyEvent3());
        }
    }

}
