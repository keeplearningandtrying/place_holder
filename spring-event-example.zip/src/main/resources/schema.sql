drop table PERSON if exists;
create table PERSON(ID serial, FIRST_NAME varchar(5) NOT NULL);