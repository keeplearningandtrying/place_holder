package com.example.events.async1;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.events.async1.AsyncEventApp.MyService;

@SpringBootTest(classes = AsyncEventApp.class)
class AsyncEventAppTests {

    @Autowired
    MyService service;

    @Test
    void createEvent() {
        service.createEvents();
    }
}
