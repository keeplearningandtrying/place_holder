package com.example.events.generics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = GenericEventApp.class)
class GenericEventAppTests {

    @Test
    void contextLoad() {

    }

}