package com.example.events.transactional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.events.transactional.TransactionalEventApp;

@SpringBootTest(classes = TransactionalEventApp.class)
class TransactionalEventAppTests {

    @Test
    void contextLoad() {

    }

}
