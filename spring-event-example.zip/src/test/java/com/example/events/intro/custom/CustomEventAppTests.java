package com.example.events.intro.custom;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;

@SpringBootTest(classes = CustomEventApp.class)
class CustomEventAppTests {

    @Autowired
    ApplicationEventPublisher publisher;

    @Test
    void testEvents() {
        publisher.publishEvent(new Event1(this, "test event1"));
        publisher.publishEvent(new Event2("test event2"));
    }
}
