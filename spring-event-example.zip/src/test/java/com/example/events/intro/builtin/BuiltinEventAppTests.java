package com.example.events.intro.builtin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = BuiltinEventApp.class)
class BuiltinEventAppTests {

    @Test
    void contextLoad() {
    }

}
