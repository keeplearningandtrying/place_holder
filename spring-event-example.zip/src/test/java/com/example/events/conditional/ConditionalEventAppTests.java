package com.example.events.conditional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.events.conditional.ConditionalEventApp.Account;
import com.example.events.conditional.ConditionalEventApp.AccountService;
import com.example.events.conditional.ConditionalEventApp.Type;

@SpringBootTest(classes = ConditionalEventApp.class)
class ConditionalEventAppTests {

    @Autowired
    AccountService service;

    @Test
    void testAccountCreatedEvents() {
        Account mark = service.createAccount("Mark", "123456", Type.CHECKING);
        service.createAccount("John", "654321", Type.SAVING);

        service.activateAccount(mark);
    }

    @Test
    void testDepositEvent() {
        Account mark = new Account("Mark", "1234");
        Account john = new Account("John", "4321");

        service.depositToAccount(mark, 150);
        service.depositToAccount(john, 50);
    }

}