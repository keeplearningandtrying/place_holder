package com.example.demo;

public class Greeting {

    private String name;
    private String word;

    public Greeting(String name, String word) {
        this.name = name;
        this.word = word;
    }
    public String getName() {
        return name;
    }
    public String getWord() {
        return word;
    }



}
