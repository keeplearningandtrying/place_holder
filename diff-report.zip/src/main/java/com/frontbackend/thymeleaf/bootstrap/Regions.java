package com.frontbackend.thymeleaf.bootstrap;

import com.frontbackend.thymeleaf.bootstrap.model.Prop;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Configuration
//@ConfigurationProperties(prefix="diff")
@Getter
@Setter
@NoArgsConstructor
public class Regions {

    private Prop region1;
    private Prop region2;
    
}
