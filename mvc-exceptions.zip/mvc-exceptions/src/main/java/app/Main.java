package app;

import java.util.Properties;

import app.demo.config.ExceptionConfiguration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;

/**
 * Main entry point for our application using Spring Boot. It can be run as an executable or as a
 * standard war file.
 *
 * <p>Details of annotations used:
 *
 * <ul>
 *   <li><code>@EnableAutoConfiguration</code>: makes Spring Boot setup its defaults.
 *   <li><code>@ComponentScan</code>: Scan for @Component classes, including @Configuration classes.
 *   <li><code>@ImportResource</code>: Import Spring XML configuration file(s).
 * </ul>
 *
 * @author Paul Chapman
 */
@SpringBootApplication
@ImportResource("classpath:mvc-configuration.xml")
public class Main extends SpringBootServletInitializer {

    /**
     * How should a <code>SimpleMappingExceptionResolver</code> be created?
     *
     * <ul>
     *   <li>DEMO (default) - Java Config is used and a custom <code>SimpleMappingExceptionResolver
     *       </code> is setup that can be enabled or disabled programmatically (just for the purpose
     *       of this demo).
     *   <li>XML - Traditional XML bean configuration is used - see <code>mvc-configuration.xml
     *       </code>.
     *   <li>JAVA - Java Configuration is used - see {@link ExceptionConfiguration}.
     *   <li>NONE - No <code>SimpleMappingExceptionResolver</code> is created.
     * </ul>
     *
     * <p>Demo mode is the default - set to "java-config" or "xml-config" to match however you
     * intend to use Spring for a more realistic setup.
     *
     * @see Profiles
     */
    protected Logger logger;

    protected Properties props = new Properties();

    /**
     * We are using the constructor to perform some useful initializations:
     *
     * <ol>
     *   <li>Set the Spring Profile to use 'controller' or 'global' which in turn selects how
     *       exceptions will be handled. Profiles are a Spring feature from V3.1 onwards.
     *   <li>Disable Thymeleaf caching so templates (HTML files with Thymeleaf namespace attributes)
     *       can be modified whilst the application is running.
     *   <li>Enable DEBUG level logging so you can see Spring MVC as its working.
     * </ol>
     */
    public Main() {
        logger = LoggerFactory.getLogger(getClass());
        logger.info("Application starting ");
    }

    /**
     * Back to the future: run the application as a Java application and it will pick up a container
     * (Tomcat, Jetty) automatically if present. Pulls in Tomcat by default, running in embedded
     * mode.
     *
     * <p>This application can also run as a traditional war file because it extends <code>
     * SpringBootServletInitializer</code> as well.
     */
    public static void main(String[] args) throws Exception {
        // Create an instance and invoke run(); Allows the contructor to perform
        // initialisation regardless of whether we are running as an application
        // or in a container.
        new Main().runAsJavaApplication(args);
    }

    /**
     * Run the application using Spring Boot. <code>SpringApplication.run</code> tells Spring Boot
     * to use this class as the initialiser for the whole application (via the class annotations
     * above). This method is only used when running as a Java application.
     */
    protected void runAsJavaApplication(String[] args) {
        SpringApplicationBuilder application = new SpringApplicationBuilder();
        configure(application);
        application.run(args);
    }

    /**
     * Configure the application using the supplied builder when running as a WAR. This method is
     * invoked automatically when running in a container and explicitly by {@link
     * #runAsJavaApplication(String[])}.
     */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        application.sources(Main.class);

        // Set additional properties.
        logger.info("Spring Boot configuratoon: properties = " + props);
        application.properties(props);

        return application;
    }
}
