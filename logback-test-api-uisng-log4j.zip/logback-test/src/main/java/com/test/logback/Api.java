package com.test.logback;

import org.apache.log4j.Logger;

public class Api {
	
	public static int add(int a, int b) {
		Logger logger = Logger.getLogger(Api.class);
		logger.info("Enter add method");
		return a + b;
	}

}
