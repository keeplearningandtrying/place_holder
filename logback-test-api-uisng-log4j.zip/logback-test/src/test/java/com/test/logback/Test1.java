package com.test.logback;

import org.apache.log4j.Logger;
import org.junit.Test;

public class Test1 {

	@Test
	public void testLog() { 
		Logger logger = Logger.getLogger(Test1.class);
		logger.trace("this is a trace level message");
		logger.info("this is an info level message");
		logger.debug("this is a debug level message");
	}
}
