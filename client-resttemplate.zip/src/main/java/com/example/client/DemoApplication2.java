package com.example.client;

import static java.time.temporal.ChronoUnit.SECONDS;

import java.time.Duration;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.SlidingWindowType;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import io.vavr.control.Try;

@Configuration
@SpringBootApplication
public class DemoApplication2 implements CommandLineRunner {

    Logger logger = LoggerFactory.getLogger(CommandLineRunner.class);

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication2.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        CircuitBreakerConfig circuitBreakerConfig = CircuitBreakerConfig.custom()
                .slidingWindowType(SlidingWindowType.COUNT_BASED).slidingWindowSize(10).failureRateThreshold(5).build();

        CircuitBreakerRegistry circuitBreakerRegistry = CircuitBreakerRegistry.of(circuitBreakerConfig);

        circuitBreakerRegistry.getEventPublisher().onEntryAdded(entryAddedEvent -> {
            CircuitBreaker addedCircuitBreaker = entryAddedEvent.getAddedEntry();
            logger.info("CircuitBreaker {} added ", addedCircuitBreaker.getName());
        }).onEntryRemoved(entryRemovedEvent -> {
            CircuitBreaker removedCircuitBreaker = entryRemovedEvent.getRemovedEntry();
            logger.info("CircuitBreaker {} removed ", removedCircuitBreaker.getName());
        });

        CircuitBreaker circuitBreaker = circuitBreakerRegistry.circuitBreaker("mybreaker");
        
        
        RetryConfig retryConfig = RetryConfig.custom()
                .maxAttempts(3)
                .waitDuration(Duration.of(2, SECONDS))
                .build();
        
        RetryRegistry registry = RetryRegistry.of(retryConfig);
        Retry retry = registry.retry("callWebService", retryConfig);

        RestTemplate restTemplate = new RestTemplate();

        for (int i = 0; i < 10; i++) {
            final int j = i;

            /*
            Supplier<String> decoratedSupplier1 = Retry.decorateSupplier(retry, () -> {
                logger.info("Calling service for request {} ...", j);
                return restTemplate.getForObject("http://localhost:8080/hello", String.class);
            });
            Supplier<String> decoratedSupplier2 = CircuitBreaker.decorateSupplier(circuitBreaker, decoratedSupplier1);
            */

            Supplier<String> decoratedSupplier1 = CircuitBreaker.decorateSupplier(circuitBreaker, () -> {
                logger.info("Calling service for request {} ...", j);
                return restTemplate.getForObject("http://localhost:8080/hello", String.class);
            });

            Supplier<String> decoratedSupplier2 = Retry.decorateSupplier(retry, () -> {
                logger.info("Retry attemp for request {} ...", j);
                return decoratedSupplier1.get(); 
            });
                


            String result = Try.ofSupplier(decoratedSupplier2).recover(throwable -> "Hello from Recovery").get();
            logger.info("result = {}", result);
        }

    }
}
