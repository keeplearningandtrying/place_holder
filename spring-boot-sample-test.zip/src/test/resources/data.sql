INSERT INTO Person(ID, NAME, EID) values (123, 'Mark Smith', '01234567');
