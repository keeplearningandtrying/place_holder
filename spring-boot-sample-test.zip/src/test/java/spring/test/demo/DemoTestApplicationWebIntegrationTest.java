package spring.test.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;

import spring.test.demo.domain.EmployerID;
import spring.test.demo.service.Employer;
import spring.test.demo.service.EmployerService;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase
class DemoTestApplicationWebIntegrationTest {

    private static final EmployerID EID = new EmployerID("01234567");

    @Autowired
    private TestRestTemplate restTemplate;

    @MockBean
    private EmployerService employerService;

    @BeforeEach
    public void setup() {
        given(this.employerService.getEmployer(EID)).willReturn(new Employer("Active Mower", "Small Business"));
    }

    @Test
    void test() {
        assertThat(this.restTemplate.getForEntity("/{name}/employer", String.class, "Mark Smith").getStatusCode())
                .isEqualTo(HttpStatus.OK);
    }

}
