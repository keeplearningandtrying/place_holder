package spring.test.demo.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.HttpServerErrorException;

import spring.test.demo.domain.EmployerID;

@ExtendWith(SpringExtension.class)
@RestClientTest({ RemoteEmployerService.class, ServiceProperties.class })
class RemoteEmployerServiceTest {

    private static final String EID = "12345678";

    @Autowired
    private RemoteEmployerService service;

    @Autowired
    private MockRestServiceServer server;

    @Test
    void getEmployerWhenEidIsNullShouldThrowException() {
        
        assertThatIllegalArgumentException().isThrownBy(() -> this.service.getEmployer(null))
                .withMessage("EID must not be null");
    }

    @Test
    void getEmployerWhenResultIsSuccessShouldReturnDetails() {
        this.server.expect(requestTo("/employer/" + EID))
                .andRespond(withSuccess(getClassPathResource("employer.json"), MediaType.APPLICATION_JSON));
        Employer details = this.service.getEmployer(new EmployerID(EID));
        assertThat(details.getName()).isEqualTo("Active Mower");
        assertThat(details.getType()).isEqualTo("Small Business");
    }

    @Test
    void getEmployerWhenResultIsNotFoundShouldThrowException() {
        this.server.expect(requestTo("/employer/" + EID)).andRespond(withStatus(HttpStatus.NOT_FOUND));
        assertThatExceptionOfType(EmployerIDNotFoundException.class)
                .isThrownBy(() -> this.service.getEmployer(new EmployerID(EID)));
    }

    @Test
    void getEmployerWhenResultIServerErrorShouldThrowException() {
        this.server.expect(requestTo("/employer/" + EID)).andRespond(withServerError());
        assertThatExceptionOfType(HttpServerErrorException.class)
                .isThrownBy(() -> this.service.getEmployer(new EmployerID(EID)));
    }

    private ClassPathResource getClassPathResource(String path) {
        return new ClassPathResource(path, getClass());
    }

}
