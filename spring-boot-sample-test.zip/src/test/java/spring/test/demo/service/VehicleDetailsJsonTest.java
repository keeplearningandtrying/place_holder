package spring.test.demo.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@JsonTest
class EmployerJsonTests {

    @Autowired
    private JacksonTester<Employer> json;

    @Test
    void serializeJson() throws Exception {
        Employer employer = new Employer("Active Mower", "Small Business");
        assertThat(this.json.write(employer)).isEqualTo("employer.json");
        assertThat(this.json.write(employer)).isEqualToJson("employer.json");
        assertThat(this.json.write(employer)).hasJsonPathStringValue("@.name");
        assertThat(this.json.write(employer)).extractingJsonPathStringValue("@.name").isEqualTo("Active Mower");
    }

    @Test
    void deserializeJson() throws Exception {
        String content = "{\"name\":\"Painter\",\"type\":\"Home Service\"}";
        assertThat(this.json.parse(content)).isEqualTo(new Employer("Painter", "Home Service"));
        assertThat(this.json.parseObject(content).getName()).isEqualTo("Painter");
    }

}
