package spring.test.demo.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import spring.test.demo.service.Employer;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PersonEmployerController.class)
class PersonEmployerControllerSeleniumTest {

    @Autowired
    private WebDriver webDriver;

    @MockBean
    private PersonEmployerService personEmployerService;

    @Test
    void getEmployerWhenRequestingTextShouldReturnMakeAndModel() {
        given(this.personEmployerService.getEmployer("Mark")).willReturn(new Employer("Active Mower", "Small Business"));
        this.webDriver.get("/Mark/employer.html");
        WebElement element = this.webDriver.findElement(By.tagName("h1"));
        assertThat(element.getText()).isEqualTo("Active Mower Small Business");
    }

}
