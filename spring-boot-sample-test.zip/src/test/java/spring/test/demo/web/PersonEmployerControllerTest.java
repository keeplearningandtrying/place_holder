package spring.test.demo.web;


import static org.hamcrest.Matchers.containsString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import spring.test.demo.DemoCommandLineRunner;
import spring.test.demo.domain.EmployerID;
import spring.test.demo.service.Employer;
import spring.test.demo.service.EmployerIDNotFoundException;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PersonEmployerController.class)
class PersonEmployerControllerTest {

    private static final EmployerID EID = new EmployerID("12345678");

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ApplicationContext applicationContext;

    @MockBean 
    private PersonEmployerService personEmployerService;

    @Test
    void getEmployerWhenRequestingTextShouldReturnMakeAndModel() throws Exception {
        given(this.personEmployerService.getEmployer("Mark Smith")).willReturn(new Employer("Active Mower", "Small Business"));
        this.mvc.perform(get("/Mark Smith/employer").accept(MediaType.TEXT_PLAIN)).andExpect(status().isOk())
                .andExpect(content().string("Active Mower Small Business"));
    }

    @Test
    void getEmployerWhenRequestingJsonShouldReturnMakeAndModel() throws Exception {
        given(this.personEmployerService.getEmployer("Mark Smith")).willReturn(new Employer("Active Mower", "Small Business"));
        this.mvc.perform(get("/Mark Smith/employer").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andExpect(content().json("{'name':'Active Mower','type':'Small Business'}"));
    }

    @Test
    void getEmployerWhenRequestingHtmlShouldReturnMakeAndModel() throws Exception {
        given(this.personEmployerService.getEmployer("Mark Smith")).willReturn(new Employer("Active Mower", "Small Business"));
        this.mvc.perform(get("/Mark Smith/employer.html").accept(MediaType.TEXT_HTML_VALUE)).andExpect(status().isOk())
                .andExpect(content().string(containsString("<h1>Active Mower Small Business</h1>")));
    }

    @Test
    void getEmployerWhenPersonNotFoundShouldReturnNotFound() throws Exception {
        given(this.personEmployerService.getEmployer("Test")).willThrow(new PersonNameNotFoundException("Test"));
        this.mvc.perform(get("/Test/employer")).andExpect(status().isNotFound());
    }

    @Test
    void getEmployerWhenEidNotFoundShouldReturnNotFound() throws Exception {
        given(this.personEmployerService.getEmployer("Test")).willThrow(new EmployerIDNotFoundException(EID));
        this.mvc.perform(get("/Test/employer")).andExpect(status().isNotFound());
    }

    // @Test(expected = NoSuchBeanDefinitionException.class)
    void welcomeCommandLineRunnerShouldNotBeAvailable() {
        // Since we're a @WebMvcTest DemoCommandLineRunner should not be available.
        this.applicationContext.getBean(DemoCommandLineRunner.class);
    }

}
