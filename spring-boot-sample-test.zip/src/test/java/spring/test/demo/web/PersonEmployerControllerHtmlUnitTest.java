package spring.test.demo.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

import spring.test.demo.service.Employer;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PersonEmployerController.class)
class PersonEmployerControllerHtmlUnitTest {

    @Autowired
    private WebClient webClient;

    @MockBean
    private PersonEmployerService personEmployerService;

    @Test
    void getEmployerWhenRequestingTextShouldReturnMakeAndModel() throws Exception {
        given(this.personEmployerService.getEmployer("Mark")).willReturn(new Employer("Active Mower", "Small Business"));
        HtmlPage page = this.webClient.getPage("/Mark/employer.html");
        assertThat(page.getBody().getTextContent()).isEqualTo("Active Mower Small Business");

    }

}
