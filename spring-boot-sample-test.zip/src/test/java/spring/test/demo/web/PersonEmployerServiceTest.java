package spring.test.demo.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import spring.test.demo.domain.Person;
import spring.test.demo.domain.PersonRepository;
import spring.test.demo.domain.EmployerID;
import spring.test.demo.service.Employer;
import spring.test.demo.service.EmployerService;
import spring.test.demo.web.PersonNameNotFoundException;
import spring.test.demo.web.PersonEmployerService;

class PersonEmployerServiceTest {

    private static final EmployerID EID = new EmployerID("12345678");

    @Mock
    private EmployerService employerService;

    @Mock
    private PersonRepository personRepository;

    private PersonEmployerService service;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        this.service = new PersonEmployerService(this.personRepository, this.employerService);
    }

    @Test
    void getEmployerWhenNameIsNullShouldThrowException() {
        assertThatIllegalArgumentException().isThrownBy(() -> this.service.getEmployer(null))
                .withMessage("Name must not be null");
    }

    @Test
    void getEmployerWhenNameNotFoundShouldThrowException() {
        given(this.personRepository.findByName(anyString())).willReturn(null);
        assertThatExceptionOfType(PersonNameNotFoundException.class)
                .isThrownBy(() -> this.service.getEmployer("sboot"));
    }

    @Test
    void getEmployerShouldReturnMakeAndModel() {
        given(this.personRepository.findByName(anyString())).willReturn(new Person("Mark Smith", EID));
        Employer details = new Employer("Honda", "Civic");
        given(this.employerService.getEmployer(EID)).willReturn(details);
        Employer actual = this.service.getEmployer("sboot");
        assertThat(actual).isEqualTo(details);
    }

}
