package spring.test.demo.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import spring.test.demo.DemoCommandLineRunner;
import spring.test.demo.service.Employer;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
class PersonEmployerControllerApplicationTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ApplicationContext applicationContext;

    @MockBean
    private PersonEmployerService personEmployerService;

    @Test
    void getEmployerWhenRequestingTextShouldReturnMakeAndModel() throws Exception {
        given(this.personEmployerService.getEmployer("Mark")).willReturn(new Employer("Active Mower", "Small Business"));
        this.mvc.perform(get("/Mark/employer").accept(MediaType.TEXT_PLAIN)).andExpect(status().isOk())
                .andExpect(content().string("Active Mower Small Business"));
    }

    @Test
    void welcomeCommandLineRunnerShouldBeAvailable() {
        // Since we're a @SpringBootTest all beans should be available.
        assertThat(this.applicationContext.getBean(DemoCommandLineRunner.class)).isNotNull();
    }

}
