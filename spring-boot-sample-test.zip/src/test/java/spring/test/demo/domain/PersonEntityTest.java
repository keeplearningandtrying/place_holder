package spring.test.demo.domain;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@DataJpaTest
class PersonEntityTest {

    private static final EmployerID EID = new EmployerID("12345678");

    @Autowired
    private TestEntityManager entityManager;

    @Test
    void createWhenNameIsNullShouldThrowException() {
        assertThatIllegalArgumentException().isThrownBy(() -> new Person(null, EID))
                .withMessage("Name must not be empty");
    }

    @Test
    void createWhenNameIsEmptyShouldThrowException() {
        assertThatIllegalArgumentException().isThrownBy(() -> new Person("", EID))
                .withMessage("Name must not be empty");
    }

    @Test
    void createWhenEidIsNullShouldThrowException() {
        assertThatIllegalArgumentException().isThrownBy(() -> new Person("sboot", null))
                .withMessage("Eid must not be null");
    }

    @Test
    void saveShouldPersistData() {
        Person person = this.entityManager.persistFlushFind(new Person("sboot", EID));
        assertThat(person.getName()).isEqualTo("sboot");
        assertThat(person.getEid()).isEqualTo(EID);
    }

}
