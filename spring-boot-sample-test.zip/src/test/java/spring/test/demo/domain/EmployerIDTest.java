package spring.test.demo.domain;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

import org.junit.jupiter.api.Test;

class EmployerIDTest {

    private static final String SAMPLE_EID = "12345678";

    @Test
    void createWhenEidIsNullShouldThrowException() {
        assertThatIllegalArgumentException().isThrownBy(() -> new EmployerID(null))
                .withMessage("EID must not be null");
    }

    @Test
    void createWhenEidIsMoreThan17CharsShouldThrowException() {
        assertThatIllegalArgumentException().isThrownBy(() -> new EmployerID("012345678901234567"))
                .withMessage("EID must be exactly 8 characters");
    }

    @Test
    void createWhenEidIsLessThan17CharsShouldThrowException() {
        assertThatIllegalArgumentException().isThrownBy(() -> new EmployerID("012345"))
                .withMessage("EID must be exactly 8 characters");
    }

    @Test
    void toStringShouldReturnEid() {
        EmployerID eid = new EmployerID(SAMPLE_EID);
        assertThat(eid.toString()).isEqualTo(SAMPLE_EID);
    }

    @Test
    void equalsAndHashCodeShouldBeBasedOnEid() {
        EmployerID eid1 = new EmployerID(SAMPLE_EID);
        EmployerID eid2 = new EmployerID("12345678");
        EmployerID eid3 = new EmployerID("87654321");
        assertThat(eid1.hashCode()).isEqualTo(eid2.hashCode());
        assertThat(eid1).isEqualTo(eid1).isEqualTo(eid2).isNotEqualTo(eid3);
    }

}
