package spring.test.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.util.Assert;

@Entity
public class Person {

    @Id
    @GeneratedValue
    private Long id;

    @Column(unique = true)
    private String name;

    private EmployerID eid;

    protected Person() {
    }

    public Person(String name, EmployerID eid) {
        Assert.hasLength(name, "Name must not be empty");
        Assert.notNull(eid, "Eid must not be null");
        this.name = name;
        this.eid = eid;
    }

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public EmployerID getEid() {
        return this.eid;
    }

}
