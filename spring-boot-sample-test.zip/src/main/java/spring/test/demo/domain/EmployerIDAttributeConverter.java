package spring.test.demo.domain;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class EmployerIDAttributeConverter implements AttributeConverter<EmployerID, String> {

    @Override
    public String convertToDatabaseColumn(EmployerID attribute) {
        return attribute.toString();
    }

    @Override
    public EmployerID convertToEntityAttribute(String dbData) {
        return new EmployerID(dbData);
    }

}
