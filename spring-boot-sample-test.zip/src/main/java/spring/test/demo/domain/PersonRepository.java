package spring.test.demo.domain;

import org.springframework.data.repository.Repository;

public interface PersonRepository extends Repository<Person, Long> {

    Person findByName(String name);

}
