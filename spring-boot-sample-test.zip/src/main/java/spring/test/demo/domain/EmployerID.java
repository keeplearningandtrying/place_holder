package spring.test.demo.domain;

import java.io.Serializable;

import org.springframework.util.Assert;

public class EmployerID implements Serializable {

    private static final long serialVersionUID = -1459478581244414478L;

    private String eid;

    public EmployerID(String eid) {
        Assert.notNull(eid, "EID must not be null");
        Assert.isTrue(eid.length() == 8, "EID must be exactly 8 characters");
        this.eid = eid;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        return this.eid.equals(((EmployerID) obj).eid);
    }

    @Override
    public int hashCode() {
        return this.eid.hashCode();
    }

    @Override
    public String toString() {
        return this.eid;
    }

}
