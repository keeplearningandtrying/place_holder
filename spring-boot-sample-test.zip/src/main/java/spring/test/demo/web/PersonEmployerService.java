package spring.test.demo.web;

import spring.test.demo.domain.Person;
import spring.test.demo.domain.PersonRepository;
import spring.test.demo.service.Employer;
import spring.test.demo.service.EmployerService;
import spring.test.demo.service.EmployerIDNotFoundException;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class PersonEmployerService {

    private final PersonRepository personRepository;

    private final EmployerService employerService;

    public PersonEmployerService(PersonRepository personRepository, EmployerService employerService) {
        this.personRepository = personRepository;
        this.employerService = employerService;
    }

    public Employer getEmployer(String name) throws PersonNameNotFoundException, EmployerIDNotFoundException {
        Assert.notNull(name, "Name must not be null");
        Person person = this.personRepository.findByName(name);
        if (person == null) {
            throw new PersonNameNotFoundException(name);
        }
        return this.employerService.getEmployer(person.getEid());
    }

}
