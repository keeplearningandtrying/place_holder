package spring.test.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import spring.test.demo.service.Employer;
import spring.test.demo.service.EmployerIDNotFoundException;

@RestController
public class PersonEmployerController {

    private PersonEmployerService personEmployerService;

    public PersonEmployerController(PersonEmployerService personEmployerService) {
        this.personEmployerService = personEmployerService;
    }

    @GetMapping(path = "/{name}/employer", produces = MediaType.TEXT_PLAIN_VALUE)
    public String getEmployerText(@PathVariable String name) {
        Employer employer = this.personEmployerService.getEmployer(name);
        return employer.getName() + " " + employer.getType();
    }

    @GetMapping(path = "/{name}/employer", produces = MediaType.APPLICATION_JSON_VALUE)
    public Employer employerJson(@PathVariable String name) {
        return this.personEmployerService.getEmployer(name);
    }

    @GetMapping(path = "/{name}/employer.html", produces = MediaType.TEXT_HTML_VALUE)
    public String employerHtml(@PathVariable String name) {
        Employer employer = this.personEmployerService.getEmployer(name);
        String employerDetail = employer.getName() + " " + employer.getType();
        return "<html><body><h1>" + employerDetail + "</h1></body></html>";
    }

    @ExceptionHandler
    @ResponseStatus(HttpStatus.NOT_FOUND)
    private void handleEidNotFound(EmployerIDNotFoundException ex) {
    }

}
