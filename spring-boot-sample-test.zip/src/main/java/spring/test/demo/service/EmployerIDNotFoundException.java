package spring.test.demo.service;

import spring.test.demo.domain.EmployerID;

public class EmployerIDNotFoundException extends RuntimeException {

    private static final long serialVersionUID = -3472281785354500393L;

    private final EmployerID eid;

    public EmployerIDNotFoundException(EmployerID eid) {
        this(eid, null);
    }

    public EmployerIDNotFoundException(EmployerID eid, Throwable cause) {
        super("Unable to find eid " + eid, cause);
        this.eid = eid;
    }

    public EmployerID getEid() {
        return this.eid;
    }

}
