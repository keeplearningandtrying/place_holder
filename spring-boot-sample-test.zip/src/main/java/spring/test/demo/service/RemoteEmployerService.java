package spring.test.demo.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import spring.test.demo.domain.EmployerID;

@Service
public class RemoteEmployerService implements EmployerService {

    private static final Log logger = LogFactory.getLog(RemoteEmployerService.class);

    private final RestTemplate restTemplate;

    public RemoteEmployerService(ServiceProperties properties, RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.rootUri(properties.getEmployerServiceRootUrl()).build();
    }

    @Override
    public Employer getEmployer(EmployerID eid) throws EmployerIDNotFoundException {
        Assert.notNull(eid, "EID must not be null");
        logger.debug("Retrieving employer data for: " + eid);
        try {
            return this.restTemplate.getForObject("/employer/{eid}", Employer.class, eid);
        } catch (HttpStatusCodeException ex) {
            if (HttpStatus.NOT_FOUND.equals(ex.getStatusCode())) {
                throw new EmployerIDNotFoundException(eid, ex);
            }
            throw ex;
        }
    }

}
