package spring.test.demo.service;

import spring.test.demo.domain.EmployerID;

public interface EmployerService {

    Employer getEmployer(EmployerID eid) throws EmployerIDNotFoundException;

}
