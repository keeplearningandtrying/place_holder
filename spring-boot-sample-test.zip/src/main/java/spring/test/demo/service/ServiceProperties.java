package spring.test.demo.service;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class ServiceProperties {

    private String employerServiceRootUrl = "http://localhost:8080/es";

    public String getEmployerServiceRootUrl() {
        return this.employerServiceRootUrl;
    }

    public void setEmployerServiceRootUrl(String employerServiceRootUrl) {
        this. employerServiceRootUrl = employerServiceRootUrl;
    }

}
