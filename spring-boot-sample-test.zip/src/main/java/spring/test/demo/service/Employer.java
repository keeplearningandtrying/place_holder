package spring.test.demo.service;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.springframework.util.Assert;

public class Employer {

    private final String name;

    private final String type;

    @JsonCreator
    public Employer(@JsonProperty("name") String name, @JsonProperty("type") String type) {
        Assert.notNull(name, "Make must not be null");
        Assert.notNull(type, "Type must not be null");
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return this.name;
    }

    public String getType() {
        return this.type;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        Employer other = (Employer) obj;
        return this.name.equals(other.name) && this.type.equals(other.type);
    }

    @Override
    public int hashCode() {
        return this.name.hashCode() * 31 + this.type.hashCode();
    }

}
