package org.apache.struts.helloworld.action;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

public class MyFilter implements Filter {

    public void init(FilterConfig config) throws ServletException {
        String testParam = config.getInitParameter("test-param");
        System.out.println("Test Param: " + testParam);
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws java.io.IOException, ServletException {

        String user = request.getParameter("user");
        if ("wei".equals(user)) {
            chain.doFilter(request, response);
        } else {
            respondWith401(response);
        }
    }

    private void respondWith401(ServletResponse response) throws IOException {
        ((HttpServletResponse) response).setStatus(401);
        response.getWriter().write("Authentication required");
    }

    public void destroy() {}
}
