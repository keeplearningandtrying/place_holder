package com.frontbackend.thymeleaf.bootstrap.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.stream.Collectors;

import com.github.difflib.text.DiffRow;
import com.github.difflib.text.DiffRow.Tag;
import com.github.difflib.text.DiffRowGenerator;

import org.springframework.stereotype.Service;

@Service
public class ReportService {

    public List<DiffRow> getDiff() throws IOException {
        List<String> list1 = Files.lines(new File("src/main/resources/sample/stage.txt").toPath()).collect(Collectors.toList());
        List<String> list2 = Files.lines(new File("src/main/resources/sample/production.txt").toPath()).collect(Collectors.toList());

        DiffRowGenerator generator = DiffRowGenerator.create()
                .showInlineDiffs(true)
                .columnWidth(Integer.MAX_VALUE) // do not wrap
                .inlineDiffByWord(true)
                .oldTag(f -> "~")
                .newTag(f -> "**")
                .build();

        List<DiffRow> rows = generator.generateDiffRows(list1, list2);
        return rows.stream().filter(row -> !row.getTag().equals(Tag.EQUAL)).collect(Collectors.toList());
    }

    public List<DiffRow> getDiffContainingKeyWord(String keyWord) throws IOException {
        return getDiff().stream()
            .filter(row -> row.getOldLine().toUpperCase().contains(keyWord.toUpperCase()) 
                        || row.getNewLine().toUpperCase().contains(keyWord.toUpperCase())).collect(Collectors.toList());
    }

}
