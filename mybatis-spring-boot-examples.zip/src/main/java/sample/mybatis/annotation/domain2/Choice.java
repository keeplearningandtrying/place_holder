package sample.mybatis.annotation.domain2;

public class Choice {

    private int id;
    private String zip;

    public Choice(int id, String zip) {
        this.id = id;
        this.zip = zip;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
    
}
