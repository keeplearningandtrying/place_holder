package sample.mybatis.annotation.mapper.ds2;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import sample.mybatis.annotation.domain.Hotel;
import sample.mybatis.annotation.domain2.Choice;

@Mapper
public interface SecondaryHotelMapper {

	Hotel selectByCityId(int cityId);

	// this works
	//Hotel selectByCityZipCode(String zipCode);

	// this works as well
	// Looks like if only one parameter, the name is not important
	Hotel selectByCityZipCode(String whatEver);

	// this works
	//Hotel selectByCityZipCode(@Param("zip") String zipCode);

	Hotel selectByCityIdAndZipCode(int city, String zip);

	// This doesn't work
	//Hotel selectByChoice(Choice choice);

	Hotel selectByChoice(@Param("choice") Choice choice);
	// this works as well
	//Hotel selectByChoice(@Param("choice") Choice choice1);

	// This doesn't work
	//Hotel selectByChoice2(@Param("choice") Choice choice);
	
	// Looks like if only one parameter, the name is not important
	Hotel selectByChoice2(Choice whatEver);
	// this works as well
	//Hotel selectByChoice2(Choice choice1);

	@SelectProvider(type=SQLUtil.class, method="selectHotelByChoice")
	Hotel selectHotelByChoice(Choice choice); 
}
