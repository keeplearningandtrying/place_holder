package sample.mybatis.annotation.mapper.ds1;

import org.apache.ibatis.annotations.Mapper;

import sample.mybatis.annotation.domain.Hotel;

@Mapper
public interface HotelMapper {

	Hotel selectByCityId(int cityId);
	
}
