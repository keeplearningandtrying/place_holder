package sample.mybatis.annotation.mapper.ds1;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import sample.mybatis.annotation.domain2.City;

@Mapper
public interface CityMapper {

	@Select("select id, name, state, country from city where state = #{state}")
	List<City> findByState(@Param("state") String state);

	@Delete("DELETE from city where state = #{state}")
	Integer deleteByState(@Param("state") String state);

	@Update("UPDATE city SET name = #{city.name} WHERE state = #{city.state}")
	Integer updateByState(@Param("city") City city);

	@Insert("INSERT INTO city ( name, state, country ) VALUES ( #{city.name}, #{city.state}, #{city.country} )")
	Integer insertCity(@Param("city") City city);

}
