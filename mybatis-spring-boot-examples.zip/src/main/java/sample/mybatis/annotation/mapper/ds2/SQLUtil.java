package sample.mybatis.annotation.mapper.ds2;

import org.apache.ibatis.jdbc.SQL;

import sample.mybatis.annotation.domain2.Choice;

public class SQLUtil {

    public String selectHotelByChoice(Choice choice){
        return new SQL() {{
            SELECT("*");
            FROM("hotel");
            if (choice != null && choice.getId() > 0) {
                WHERE("city = #{id} ");
            }
            if (choice != null && !choice.getZip().isBlank()) {
                WHERE("zip = #{zip} ");
            }
        }}.toString();
    }
    
}
