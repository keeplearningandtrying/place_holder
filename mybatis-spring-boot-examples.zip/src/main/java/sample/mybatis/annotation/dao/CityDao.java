package sample.mybatis.annotation.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import sample.mybatis.annotation.domain2.City;

@Component
public class CityDao {

	private final SqlSession sqlSession;

	public CityDao(@Qualifier("primarySqlSessionTemplate") SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public City selectCityById(long id) {
		return this.sqlSession.selectOne("selectCityById", id);
	}

}
