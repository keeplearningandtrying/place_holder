package sample.mybatis.annotation.service;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import sample.mybatis.annotation.domain2.City;
import sample.mybatis.annotation.mapper.ds1.CityMapper;
import sample.mybatis.annotation.mapper.ds2.SecondaryCityMapper;

@Component
public class DataService {

	private final CityMapper cityMapper;
	private final SecondaryCityMapper secondaryCityMapper;

	private JdbcTemplate jt;

	public DataService(CityMapper cityMapper, SecondaryCityMapper secondaryCityMapper,
			@Qualifier("secondaryDataSource") DataSource dataSource) {
		this.cityMapper = cityMapper;
		this.secondaryCityMapper = secondaryCityMapper;
		jt = new JdbcTemplate(dataSource);
	}

	@Transactional
	public void insert() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);
	}

	// Try to comment out @Transactional to watch the behavior
	@Transactional
	public void inserts() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("USA");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);
	}

	@Transactional
	public void insertIntoTwoDSOk() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		secondaryCityMapper.insertCity(city);
	}

	@Transactional
	public void insertIntoTwoDSFail() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("USA");
		city.setName("LA");
		city.setState("CA");
		secondaryCityMapper.insertCity(city);
	}

	@Transactional
	public void insertIntoTwoDSOkUsingMapperAndJdbcTemplate() {
		City city = new City();
		city.setCountry("US");
		city.setName("Indy");
		city.setState("IN");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("US");
		city.setName("Columbia");
		city.setState("MO");

		jt.update("INSERT INTO city ( name, state, country ) VALUES (?, ?, ?)",
				new Object[] { city.getName(), city.getState(), city.getCountry() });
	}

	// Try to comment out @Transactional to watch the behavior
	@Transactional
	public void insertIntoTwoDSFailUsingMapperAndJdbcTemplate() {
		City city = new City();
		city.setCountry("US");
		city.setName("Indy");
		city.setState("IN");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("USA");
		city.setName("Columbia");
		city.setState("MO");

		jt.update("INSERT INTO city ( name, state, country ) VALUES (?, ?, ?)",
				new Object[] { city.getName(), city.getState(), city.getCountry() });
	}

}
