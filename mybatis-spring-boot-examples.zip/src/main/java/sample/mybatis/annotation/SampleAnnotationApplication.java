package sample.mybatis.annotation;

import java.sql.Types;
import java.util.List;
import java.util.function.Consumer;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

import sample.mybatis.annotation.dao.CityDao;
import sample.mybatis.annotation.domain2.Choice;
import sample.mybatis.annotation.domain2.City;
import sample.mybatis.annotation.mapper.ds1.CityMapper;
import sample.mybatis.annotation.mapper.ds1.HotelMapper;
import sample.mybatis.annotation.mapper.ds2.SecondaryCityMapper;
import sample.mybatis.annotation.mapper.ds2.SecondaryHotelMapper;
import sample.mybatis.annotation.service.DataService;
@SpringBootApplication
public class SampleAnnotationApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SampleAnnotationApplication.class, args);
	}

	private final CityMapper cityMapper;
	private final HotelMapper hotelMapper;
	private final CityDao cityDao;
	private final DataService dataSerice;

	@Autowired
	private SecondaryCityMapper secondaryCityMapper;

	@Autowired
	private SecondaryHotelMapper secondaryHotelMapper;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("primaryDataSource")
	private DataSource primaryDataSource;

	@Autowired
	@Qualifier("secondaryDataSource")
	private DataSource secondaryDataSource;

	public SampleAnnotationApplication(CityMapper cityMapper, HotelMapper hotelMapper, CityDao cityDao,
			DataService dataService) {
		this.cityMapper = cityMapper;
		this.hotelMapper = hotelMapper;
		this.cityDao = cityDao;
		this.dataSerice = dataService;
	}

	@Override
	public void run(String... args) {
		System.out.println("=======Jdbc template ==========");

		System.out.println("=======use default Jdbc template ==========");

		Consumer<City> printCity = (City c) -> System.out.println(c);

		jdbcTemplate.query(
				"select id, name, state, country from city where state = ?", new Object[] { "CA" },
				new int[] { Types.VARCHAR },
				(rs, rowNum) -> new City(rs.getLong("id"), rs.getString("name"), rs.getString("state"),
						rs.getString("country"))
		// ).forEach(city -> System.out.println(city));
		).forEach(printCity);

		System.out.println("=======use primary Jdbc template ==========");
		JdbcTemplate jtPrimary = new JdbcTemplate(primaryDataSource);
		jtPrimary.query(
				"select id, name, state, country from city where state = ?", new Object[] { "CA" },
				new int[] { Types.VARCHAR },
				(rs, rowNum) -> new City(rs.getLong("id"), rs.getString("name"), rs.getString("state"),
						rs.getString("country")))
				.forEach(city -> System.out.println(city));

		System.out.println("=======use secondary Jdbc template ==========");
		JdbcTemplate jtSecondary = new JdbcTemplate(secondaryDataSource);
		jtSecondary.query(
				"select id, name, state, country from city where state = ?", new Object[] { "CA" },
				new int[] { Types.VARCHAR },
				(rs, rowNum) -> new City(rs.getLong("id"), rs.getString("name"), rs.getString("state"),
						rs.getString("country")))
				.forEach(city -> System.out.println(city));

		System.out.println("=======Primay DS part 1==========");
		List<City> cities = cityMapper.findByState("CA");

		City sf = cities.get(0);

		printCities(cities);

		cityMapper.deleteByState("CA");

		cities = cityMapper.findByState("CA");
		printCities(cities);

		cityMapper.insertCity(sf);
		cities = cityMapper.findByState("CA");
		printCities(cities);

		sf.setName("San Diego");
		cityMapper.updateByState(sf);
		cities = cityMapper.findByState("CA");
		printCities(cities);

		System.out.println("=======Primay DS part 2 ==========");
		System.out.println(cityDao.selectCityById(2));
		System.out.println(cityMapper.findByState("CA"));
		System.out.println(hotelMapper.selectByCityId(1));


		System.out.println("=======Primay DS uisng data service==========");
		dataSerice.insert();
		cities = cityMapper.findByState("CA");
		printCities(cities);

		try {
			dataSerice.inserts();
		} catch (Exception e) {

		}

		cities = cityMapper.findByState("CA");
		printCities(cities);

		System.out.println("=======Secondary DS part 1 ==========");
		cities = secondaryCityMapper.findByState("CA");
		printCities(cities);

		System.out.println(secondaryHotelMapper.selectByCityId(1));

		System.out.println(secondaryHotelMapper.selectByCityZipCode("4001"));
		System.out.println(secondaryHotelMapper.selectByCityZipCode(""));
		System.out.println(secondaryHotelMapper.selectByCityZipCode(null));

		System.out.println(secondaryHotelMapper.selectByCityIdAndZipCode(1, "4001"));

		System.out.println(secondaryHotelMapper.selectByCityIdAndZipCode(1, "4002"));

		Choice choice = new Choice(1, "4001");
		System.out.println(secondaryHotelMapper.selectByChoice(choice));
		System.out.println(secondaryHotelMapper.selectByChoice(choice));
		
		System.out.println(secondaryHotelMapper.selectByChoice2(choice));

		System.out.println(secondaryHotelMapper.selectHotelByChoice(choice));

		System.out.println(secondaryHotelMapper.selectHotelByChoice(new Choice(-1, "4001")));

		System.out.println("=======Both DS==========");

		dataSerice.insertIntoTwoDSOk();

		System.out.println("=======Both DS - DS1==========");
		cities = cityMapper.findByState("CA");
		printCities(cities);

		System.out.println("=======Both DS - DS2==========");
		cities = secondaryCityMapper.findByState("CA");
		printCities(cities);

		try {
			dataSerice.insertIntoTwoDSFail();
		} catch (Exception e) {

		}

		System.out.println("=======Both DS - DS1==========");
		cities = cityMapper.findByState("CA");
		printCities(cities);

		System.out.println("=======Both DS - DS2==========");
		cities = secondaryCityMapper.findByState("CA");
		printCities(cities);

		System.out.println("======= MyBatis and JdbcTemplate together==========");
		System.out.println("======= Insert into DS1 and DS2 ok ==========");

		dataSerice.insertIntoTwoDSOkUsingMapperAndJdbcTemplate();

		System.out.println("=======- DS1==========");
		cities = cityMapper.findByState("IN");
		printCities(cities);

		System.out.println("=======- DS2==========");
		cities = secondaryCityMapper.findByState("MO");
		printCities(cities);

		System.out.println("======= Insert into DS1 and DS2 rollback ==========");
		try {
			dataSerice.insertIntoTwoDSFailUsingMapperAndJdbcTemplate();
		} catch (Exception e) {
		}
		System.out.println("=======- DS1==========");
		cities = cityMapper.findByState("IN");
		printCities(cities);

		System.out.println("=======- DS2==========");
		cities = secondaryCityMapper.findByState("MO");
		printCities(cities);
	}

	void printCities(List<City> cities) {
		System.out.println("-- print cites --");
		cities.forEach(c -> System.out.println(c));
	}

}
