package sample.mybatis.annotation.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;

import sample.mybatis.annotation.domain2.City;
import sample.mybatis.annotation.mapper.ds1.CityMapper;

@MybatisTest
class CityMapperTest {

	@Autowired
	private CityMapper cityMapper;

	@Test
	void findByStateTest() {
		List<City> cities = cityMapper.findByState("CA");
		assertThat(cities.get(0).getId()).isEqualTo(1);
		assertThat(cities.get(0).getName()).isEqualTo("San Francisco");
		assertThat(cities.get(0).getState()).isEqualTo("CA");
		assertThat(cities.get(0).getCountry()).isEqualTo("US");
	}

}
