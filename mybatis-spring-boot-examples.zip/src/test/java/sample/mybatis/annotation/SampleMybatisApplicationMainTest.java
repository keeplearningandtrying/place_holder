package sample.mybatis.annotation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import extensions.annotation.CaptureSystemOutput;
import extensions.annotation.CaptureSystemOutput.OutputCapture;

@CaptureSystemOutput
class SampleMybatisApplicationMainTest {

	@Test
	void test(OutputCapture outputCapture) {
		SampleAnnotationApplication.main(new String[] {});
		String output = outputCapture.toString();
		//assertThat(output).contains("1,San Francisco,CA,US");
		assertThat(output).contains("CA,US");
	}

}
