package sample.mybatis.annotation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import extensions.annotation.CaptureSystemOutput;
import extensions.annotation.CaptureSystemOutput.OutputCapture;

@CaptureSystemOutput
@SpringBootTest
class SampleMybatisApplicationTest {

	@Test
	void test(OutputCapture outputCapture) {
		String output = outputCapture.toString();
		//assertThat(output).contains("1,San Francisco,CA,US");
		assertThat(output).contains("CA,US");

	}

}
