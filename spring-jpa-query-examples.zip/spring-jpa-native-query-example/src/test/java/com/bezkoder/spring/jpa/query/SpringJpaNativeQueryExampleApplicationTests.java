package com.bezkoder.spring.jpa.query;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaNativeQueryExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
