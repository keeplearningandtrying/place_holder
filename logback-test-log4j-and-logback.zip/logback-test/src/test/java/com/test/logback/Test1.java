package com.test.logback;

import org.apache.log4j.Logger;
import org.junit.Test;

public class Test1 {

	@Test
	public void testLog() { 
		Logger logger = Logger.getLogger(Test1.class);
		logger.trace("this is a trace level message");
		logger.info("this is an info level message");
		logger.debug("this is a debug level message");
		
		int result = Api.add(10, 20);
		
		org.slf4j.Logger slf4jLogger = org.slf4j.LoggerFactory.getLogger(Test1.class);

		slf4jLogger.trace("this is a trace level message");
		slf4jLogger.info("this is an info level message");
		slf4jLogger.debug("this is a debug level message");
	}
}
