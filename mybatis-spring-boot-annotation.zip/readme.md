jdbc:h2:file:./d/wei/dev/java/external/mybatis-spring-boot-starter/mybatis-spring-boot-samples/mybatis-spring-boot-sample-annotation/city-db


* https://mdwgti16.github.io/spring%20boot/spring_boot_mybatis/
* https://mdwgti16.github.io/spring%20boot/spring_boot_mybatis_multi/#

* https://github.com/trof808/mybatis-multiple-datasources-example
* https://developpaper.com/mybatis-dynamic-mapping-this-time-i-finally-got-it/
* https://www.baeldung.com/mybatis
* https://www.codeleading.com/article/47775586247/
* https://www.codetd.com/en/article/7637227


--------

@Component
public interface TestCaseRunMapper {
    @Select("SELECT * FROM stat_test_case_run limit 20")
    @Results({
            @Result(property = "startDate", column = "start_date"),
            @Result(property = "endDate", column = "end_date"),
            @Result(property = "testKey", column = "test_key"),
            @Result(property = "userKey", column = "user_key"),
            @Result(property = "testRunKey", column = "run_key"),
            @Result(property = "testPlanKey", column = "test_plan_key"),
    })
    List<TestCaseRun> findAll();
}

---

@Results({
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "n"),
            @Result(property = "email", column = "e"),
            @Result(property = "grade", column = "g")
    })
    @Select("select email as e,name as n,grade as g,id as id from student where id=#{id}")
    Student getStudentById(Long id);


Read more: https://javarevisited.blogspot.com/2022/01/how-to-use-spring-boot-and-mybatis-in-java.html#ixzz7O84QrhlN


----

https://github.com/mdwgti16/mdwgti16.github.io/blob/master/_posts/spring/2021-02-14-spring_boot_mybatis.md
---
title: Spring Boot - Mybatis 연동
layout: single
author_profile: true
read_time: true
comments: null
share: true
related: true
date: '2021-02-14 20:27:28 +0900'
categories:
- Spring Boot
---

> ## Spring Boot - Mybatis 연동

* ### Dependency 설정 
	pom.xml
	```
	<dependency>
		<groupId>org.mybatis.spring.boot</groupId>
		<artifactId>mybatis-spring-boot-starter</artifactId>
		<version>2.1.4</version>
	</dependency>
	<dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-data-jdbc</artifactId>
	</dependency>
	<dependency>
		<groupId>mysql</groupId>
		<artifactId>mysql-connector-java</artifactId>
		<scope>runtime</scope>
	</dependency>
	<dependency>
		<groupId>org.mariadb.jdbc</groupId>
		<artifactId>mariadb-java-client</artifactId>
		<scope>runtime</scope>
	</dependency>
	```
	
* ### Hikari Datasource 환경 설정
	application.yml
	```
	spring:
	datasource:
		hikari:
		driver-class-name: com.mysql.cj.jdbc.Driver
		jdbc-url: jdbc:mysql://localhost:3306/testdb?useSSL=false&useUnicode=true&characterEncoding=utf8&serverTimezone=UTC
		username: root
		password: 1234
		maximum-pool-size: 50
		max-lifetime: 30000
		idle-timeout: 28000
		connection-timeout: 0
		transaction-isolation: TRANSACTION_READ_UNCOMMITTED
	```
* ### DataSuorce 설정
	MariaDataSourceConfiguration.java
	```
	@Configuration
	public class MariaDataSourceConfiguration {

		@Bean
		@Qualifier("hikariConfig")
		@ConfigurationProperties(prefix="spring.datasource.hikari")
		public HikariConfig hikariConfig() {
			return new HikariConfig();
		}

		@Bean
		@Primary
		@Qualifier("dataSource")
		public DataSource dataSource() throws Exception {
			return new HikariDataSource(hikariConfig());
		}
	}
	```
* ### MyBatis 설정	
	MyBatisConfiguration.java
	```
	@Configuration
	public class MyBatisConfiguration {
		@Primary
		@Bean(name = "sqlSessionFactory")
		public SqlSessionFactory sqlSessionFactory(
				@Qualifier("dataSource") DataSource dataSource, ApplicationContext applicationContext) throws Exception {
			SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
			sqlSessionFactoryBean.setDataSource(dataSource);
			sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:mybatis/mybatis-config.xml"));
			sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mybatis/**/*.xml"));
			return sqlSessionFactoryBean.getObject();
		}

		@Primary
		@Bean(name = "sqlSessionTemplate")
		public SqlSessionTemplate sqlSessionTemplate(
				@Qualifier("sqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
			return new SqlSessionTemplate(sqlSessionFactory);
		}
	}
	```
	mybatis-config.xml
	```
	<?xml version="1.0" encoding="UTF-8"?>
	<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN" "http://mybatis.org/dtd/mybatis-3-config.dtd">

	<configuration>

		<settings>
			<setting name="mapUnderscoreToCamelCase" value="true"/>
		</settings>

		<typeAliases>
			<typeAlias alias="userDto" type="com.example.dto.UserDto"/>
		</typeAliases>

		<typeHandlers>
		</typeHandlers>

	</configuration>
	```	
	##### 공식 문서를 보면 datasource를 감지해서 SqlSessionFactory을 만들고, 만들어진 SqlSessionFactory로 SqlSessionTemplate을 자동으로 만든다고 한다. 따라서 특별한 설정이 필요하지 않을 경우 위의 MyBatisConfiguration.class는 없어도 문제가 없다.

* ### DTO 생성
	UserDto.class
	```
	@Data
	public class UserDto {
		String id;
		String password;
		String name;
		String email;
	}
	```	
* ### 세 가지 사용 방법
	* ### Mapper 사용
		UserMapper.class
		```
		@Mapper
		public interface UserMapper {
			@Select("SELECT * FROM user WHERE id = #{id}")
			UserDto findById(@Param("id") String id);
		}
		```	
	* ### SqlSessionFactory 사용
		UserDaoMapper.class
		```
		@Mapper
		public interface UserDaoMapper {
			UserDto selectUserById(String id);
		}
		```	
		user-dao-mapper.xml
		```
		<?xml version="1.0" encoding="UTF-8"?>
		<!DOCTYPE mapper
				PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
				"http://mybatis.org/dtd/mybatis-3-mapper.dtd">

		<mapper namespace="com.example.dao.UserDaoMapper">
			<select id="selectUserById" parameterType="String" resultType="UserDto">
				SELECT *
				FROM USER
				WHERE id = #{value}
			</select>
		</mapper>
		```
	* ### SqlSessionTemplate 사용
		UserDao.class
		```
		@Component
		public class UserDao {
			private final SqlSession sqlSession;

			public UserDao(@Qualifier("sqlSessionTemplate") SqlSession sqlSession) {
				this.sqlSession = sqlSession;
			}

			public UserDto selectUserById(String id){
				return this.sqlSession.selectOne("com.example.dao.UserDao.selectUserById", id);
			}
		}
		```
		user-dao.xml
		```
		<?xml version="1.0" encoding="UTF-8"?>
		<!DOCTYPE mapper
				PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
				"http://mybatis.org/dtd/mybatis-3-mapper.dtd">

		<mapper namespace="com.example.dao.UserDao">
			<select id="selectUserById" parameterType="String" resultType="UserDto">
				SELECT *
				FROM USER
				WHERE id = #{value}
			</select>
		</mapper>
		```
* ### 실행 및 결과
	TestMyBatis.class
	```
	@SpringBootApplication
	@Slf4j
	public class TestMyBatisApplication implements CommandLineRunner {

		private final UserMapper userMapper;
		private final UserDao userDao;

		public TestMyBatisApplication(UserMapper userMapper, UserDao userDao) {
			this.userMapper = userMapper;
			this.userDao = userDao;
		}

		@Autowired
		private UserDaoMapper userDaoMapper;

		public static void main(String[] args) {
			SpringApplication.run(TestMyBatisApplication.class, args);

		}

		@Override
		public void run(String... args) throws Exception {
			log.info("result -> {}",this.userMapper.findById("abc"));
			log.info("result -> {}",this.userDao.selectUserById("abc"));
			log.info("result -> {}",this.userDaoMapper.selectUserById("abc"));
		}
	}
	```
	
	result log
	```
 	result -> UserDto(id=abc, password=qwer, name=1234, email=zxcv)
	result -> UserDto(id=abc, password=qwer, name=1234, email=zxcv)
 	result -> UserDto(id=abc, password=qwer, name=1234, email=zxcv)
	```
> ###### [Introduction What is MyBatis-Spring-Boot-Starter?](http://mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure/)
> ###### [MyBatis @Mapper 인터페이스는 어떻게 스프링 빈으로 와이어될 수 있을까?](http://wiki.plateer.com/pages/viewpage.action?pageId=7767258)



-----

https://raw.githubusercontent.com/mdwgti16/mdwgti16.github.io/master/_posts/spring/2021-02-15-spring_boot_mybatis_multi.md
---
title: Spring Boot - Mybatis Multiple Datasource 연동
layout: single
author_profile: true
read_time: true
comments: null
share: true
related: true
date: '2021-02-15 22:49:28 +0900'
categories:
- Spring Boot
---

> ## Spring Boot - Mybatis Multiple Datasource 연동
#### 기본적인 MyBatis 연동 방법은 [Spring Boot - Mybatis 연동](https://mdwgti16.github.io/spring%20boot/spring_boot_mybatis/) 참고

* ### Multiple Hikari Datasource 환경 설정
	application.yml
	```
    spring:
      datasource:
        hikari:
            primary:
              driver-class-name: com.mysql.cj.jdbc.Driver
              jdbc-url: jdbc:mysql://localhost:3306/testdb?useSSL=false&    useUnicode=true&characterEncoding=utf8&serverTimezone=UTC
              username: root
              password: 1234
              maximum-pool-size: 50
              max-lifetime: 30000
              idle-timeout: 28000
              connection-timeout: 0
              transaction-isolation: TRANSACTION_READ_UNCOMMITTED
            secondary:
              driver-class-name: com.mysql.cj.jdbc.Driver
              jdbc-url: jdbc:mysql://localhost:3306/testdb2?useSSL=false&    useUnicode=true&characterEncoding=utf8&serverTimezone=UTC
              username: root
              password: 1234
              maximum-pool-size: 50
              max-lifetime: 30000
              idle-timeout: 28000
              connection-timeout: 0
              transaction-isolation: TRANSACTION_READ_UNCOMMITTED
    ```
* ### Multiple DataSuorce 설정
	MultipleMariaDataSourceConfiguration.java
	```
	@Configuration
	public class MultipleMariaDataSourceConfiguration {

		@Bean
		@Primary
		@Qualifier("primaryHikariConfig")
		@ConfigurationProperties(prefix="spring.datasource.hikari.primary")
		public HikariConfig primaryHikariConfig() {
			return new HikariConfig();
		}

		@Bean
		@Primary
		@Qualifier("primaryDataSource")
		public DataSource primaryDataSource() throws Exception {
			return new HikariDataSource(primaryHikariConfig());
		}
		@Bean
		@Qualifier("secondaryHikariConfig")
		@ConfigurationProperties(prefix="spring.datasource.hikari.secondary")
		public HikariConfig secondaryHikariConfig() {
			return new HikariConfig();
		}

		@Bean
		@Qualifier("secondaryDataSource")
		public DataSource secondaryDataSource() throws Exception {
			return new HikariDataSource(secondaryHikariConfig());
		}
	}
	```
	##### DataSource가 2개 이상일 경우 기본으로 사용 할 DataSource를 @Primary 어노테이션으로 지정 해야 됨.
* ### MyBatis 설정	
	PrimaryMyBatisConfiguration.java
	```
	@Configuration
	public class MyBatisPrimaryConfiguration {
		@Primary
		@Bean(name = "primarySqlSessionFactory")
		public SqlSessionFactory sqlSessionFactory(
				@Qualifier("primaryDataSource") DataSource dataSource, ApplicationContext applicationContext) throws Exception {
			SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
			sqlSessionFactoryBean.setDataSource(dataSource);
			sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:mybatis/mybatis-config.xml"));
			sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mybatis/mapper/**/*.xml"));

			return sqlSessionFactoryBean.getObject();
		}

		@Primary
		@Bean(name = "primarySqlSessionTemplate")
		public SqlSessionTemplate sqlSessionTemplate(
				@Qualifier("primarySqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
			return new SqlSessionTemplate(sqlSessionFactory);
		}
	}	
	```
	SecondaryMyBatisConfiguration.class
	```
	@Configuration
	public class SecondaryMyBatisConfiguration {
		@Bean(name = "secondarySqlSessionFactory")
		public SqlSessionFactory sqlSessionFactory(
				@Qualifier("secondaryDataSource") DataSource dataSource, ApplicationContext applicationContext) throws Exception {
			SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
			sqlSessionFactoryBean.setDataSource(dataSource);
			sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:mybatis/mybatis-config.xml"));
			sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mybatis/mapper/**/*.xml"));

			return sqlSessionFactoryBean.getObject();
		}

		@Bean(name = "secondarySqlSessionTemplate")
		public SqlSessionTemplate sqlSessionTemplate(
				@Qualifier("secondarySqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
			return new SqlSessionTemplate(sqlSessionFactory);
		}
	}
	```	
	##### DataSource와 마찬가지로 SqlSessionFactory와 SqlSessionTemplate이 2개 이상일 경우 기본으로 사용 할 Bean을 @Primary 어노테이션으로 지정 해야 됨.

* ### DTO 생성
	UserDto.class
	```
	@Data
	public class UserDto {
		String id;
		String password;
		String name;
		String email;
	}
	```	
* ### 세 가지 사용 방법
	* ### Mapper 사용
		UserMapper.class
		```
		@Mapper
		public interface UserMapper {
			@Select("SELECT * FROM user WHERE id = #{id}")
			UserDto findById(@Param("id") String id);
		}
		```	
	* ### SqlSessionFactory 사용
		UserDaoMapper.class
		```
		@Mapper
		public interface UserDaoMapper {
			UserDto selectUserById(String id);
		}
		```	
		user-dao-mapper.xml
		```
		<?xml version="1.0" encoding="UTF-8"?>
		<!DOCTYPE mapper
				PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
				"http://mybatis.org/dtd/mybatis-3-mapper.dtd">

		<mapper namespace="com.example.dao.UserDaoMapper">
			<select id="selectUserById" parameterType="String" resultType="UserDto">
				SELECT *
				FROM USER
				WHERE id = #{value}
			</select>
		</mapper>
		```
	* ### SqlSessionTemplate 사용
		UserDao.class
		```
		@Component
		public class UserDao {
			private final SqlSession sqlSession;

			public UserDao(@Qualifier("secondarySqlSessionTemplate") SqlSession sqlSession) {
				this.sqlSession = sqlSession;
			}

			public UserDto selectUserById(String id){
				return this.sqlSession.selectOne("com.example.dao.UserDao.selectUserById", id);
			}
		}
		```
		user-dao.xml
		```
		<?xml version="1.0" encoding="UTF-8"?>
		<!DOCTYPE mapper
				PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
				"http://mybatis.org/dtd/mybatis-3-mapper.dtd">

		<mapper namespace="com.example.dao.UserDao">
			<select id="selectUserById" parameterType="String" resultType="UserDto">
				SELECT *
				FROM USER
				WHERE id = #{value}
			</select>
		</mapper>
		```
* ### 실행 및 결과
	TestMyBatis.class
	```
	@SpringBootApplication
	@Slf4j
	public class TestMyBatisApplication implements CommandLineRunner {

		private final UserMapper userMapper;
		private final UserDao userDao;

		public TestMyBatisApplication(UserMapper userMapper, UserDao userDao) {
			this.userMapper = userMapper;
			this.userDao = userDao;
		}

		@Autowired
		private UserDaoMapper userDaoMapper;

		public static void main(String[] args) {
			SpringApplication.run(TestMyBatisApplication.class, args);

		}

		@Override
		public void run(String... args) throws Exception {
			log.info("result -> {}",this.userMapper.findById("abc"));
			log.info("result -> {}",this.userDao.selectUserById("abc"));
			log.info("result -> {}",this.userDaoMapper.selectUserById("abc"));
		}
	}
	```
	
	result log
	```
 	result -> UserDto(id=abc, password=qwer, name=1234, email=zxcv)
	result -> null
 	result -> UserDto(id=abc, password=qwer, name=1234, email=zxcv)
	```
> ###### [Spring Boot 2 Multiple DataSource](https://gigas-blog.tistory.com/122)