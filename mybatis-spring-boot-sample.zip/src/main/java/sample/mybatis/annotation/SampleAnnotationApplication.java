/*
 *    Copyright 2015-2021 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package sample.mybatis.annotation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import sample.mybatis.annotation.dao.CityDao;
import sample.mybatis.annotation.domain2.City;
import sample.mybatis.annotation.mapper.ds1.CityMapper;
import sample.mybatis.annotation.mapper.ds1.HotelMapper;
import sample.mybatis.annotation.mapper.ds2.SecondaryCityMapper;
import sample.mybatis.annotation.mapper.ds2.SecondaryHotelMapper;
import sample.mybatis.annotation.service.DataService;

@SpringBootApplication
public class SampleAnnotationApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SampleAnnotationApplication.class, args);
	}

	private final CityMapper cityMapper;
	private final HotelMapper hotelMapper;
	private final CityDao cityDao;
	private final DataService dataSerice;
	
	@Autowired
	private SecondaryCityMapper secondaryCityMapper;

	@Autowired
	private SecondaryHotelMapper secondaryHotelMapper;

	public SampleAnnotationApplication(CityMapper cityMapper, HotelMapper hotelMapper, CityDao cityDao,
			DataService dataService) {
		this.cityMapper = cityMapper;
		this.hotelMapper = hotelMapper;
		this.cityDao = cityDao;
		this.dataSerice = dataService;
	}

	@Override
	public void run(String... args) {

		System.out.println("=======Primay DS part 1==========");
		List<City> cities = cityMapper.findByState("CA");

		City sf = cities.get(0);

		printCities(cities);

		cityMapper.deleteByState("CA");

		cities = cityMapper.findByState("CA");
		printCities(cities);

		cityMapper.insertCity(sf);
		cities = cityMapper.findByState("CA");
		printCities(cities);

		sf.setName("San Diego");
		cityMapper.updateByState(sf);
		cities = cityMapper.findByState("CA");
		printCities(cities);

		System.out.println("=======Primay DS part 2 ==========");
		System.out.println(this.cityDao.selectCityById(2));
		System.out.println(this.cityMapper.findByState("CA"));
		System.out.println(this.hotelMapper.selectByCityId(1));

		System.out.println("=======Primay DS uisng data service==========");
		dataSerice.insert();
		cities = cityMapper.findByState("CA");
		printCities(cities);

		try {
			dataSerice.inserts();
		} catch (Exception e) {

		}

		cities = cityMapper.findByState("CA");
		printCities(cities);
		
		System.out.println("=======Secondary DS part 1 ==========");
		cities = secondaryCityMapper.findByState("CA");
		printCities(cities);
		
		System.out.println(this.secondaryHotelMapper.selectByCityId(1));
		
		System.out.println("=======Both DS==========");

		dataSerice.insertIntoTwoDSOk();
		
		System.out.println("=======Both DS - DS1==========");
		cities = cityMapper.findByState("CA");
		printCities(cities);

		System.out.println("=======Both DS - DS2==========");
		cities = secondaryCityMapper.findByState("CA");
		printCities(cities);

		try {
			dataSerice.insertIntoTwoDSFail();
		} catch (Exception e) {

		}

		System.out.println("=======Both DS - DS1==========");
		cities = cityMapper.findByState("CA");
		printCities(cities);

		System.out.println("=======Both DS - DS2==========");
		cities = secondaryCityMapper.findByState("CA");
		printCities(cities);
	}

	void printCities(List<City> cities) {
		System.out.println("-- print cites --");
		cities.forEach(c -> System.out.println(c));
	}

}
