package sample.mybatis.annotation.service;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import sample.mybatis.annotation.domain2.City;
import sample.mybatis.annotation.mapper.ds1.CityMapper;
import sample.mybatis.annotation.mapper.ds2.SecondaryCityMapper;

@Component
public class DataService {

	private final CityMapper cityMapper;
	private final SecondaryCityMapper secondaryCityMapper;

	public DataService(CityMapper cityMapper, SecondaryCityMapper secondaryCityMapper) {
		this.cityMapper = cityMapper;
		this.secondaryCityMapper = secondaryCityMapper;
	}

	@Transactional
	public void insert() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);
	}

	// Try to comment out line 31 and see the behavior
	@Transactional
	public void inserts() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("USA");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);

	}

	@Transactional
	public void insertIntoTwoDSOk() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		secondaryCityMapper.insertCity(city);

	}

	@Transactional
	public void insertIntoTwoDSFail() {
		City city = new City();
		city.setCountry("US");
		city.setName("LA");
		city.setState("CA");
		cityMapper.insertCity(city);

		city = new City();
		city.setCountry("USA");
		city.setName("LA");
		city.setState("CA");
		secondaryCityMapper.insertCity(city);

	}

}
