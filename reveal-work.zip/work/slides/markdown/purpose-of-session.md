### My goals for you.
   
    - Get started with metrics and the Spring Boot actuator
    - Use Micrometer for custom metrics
    
    - Use Sleuth to get the benefits of tracing
      in distributed systems
    - Use the Spring Boot integration with Wavefront
    
    - Think about observability before going to production

Notes:
- Keep things at the 101 level