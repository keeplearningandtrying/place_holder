## My story

Once upon a time, just a few years ago 

Notes:
- EAR with dozens of WAR 
- Cover everything with APM agents to solve all of your problems
  - Spoiler Alert: It didn't work
- Microservices were gaining popularity
- Docker sounded interesting
- I was still throwing things over the wall
  - Some other group would handle monitoring
- APM wasn't the solution to our highest priority problems
  - We needed observability
Good
- Focus on one component - feature release
- Getting to production faster
- The business value was very visible
- Still running on VMs not containers
Bad
- Still shared monolithic database
- Difficult to pinpoint issues
- Configuration management sprawl
- We had created a distributed monolith