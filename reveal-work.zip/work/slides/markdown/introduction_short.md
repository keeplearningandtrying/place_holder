## Introduction

- 800 days as Platform Architect
  - VMware by way of Pivotal
- Certified Kubernetes Application Developer (CKAD)
- @dashaun on (Twitter|GitHub|GitLab)