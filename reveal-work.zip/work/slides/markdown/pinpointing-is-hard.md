## Pinpointing issues is hard

 - Monolith
 - Microservices
 - DB connections
 - Content Delivery Networks
 - Load Balancers
 - Sticky Sessions

Notes:
- One agent for each service cluster that may have 20 instances
- Still running on 100s of VMs
- APM didn't run locally
- No way to determine app characteristics before production