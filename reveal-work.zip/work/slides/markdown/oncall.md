## Pride of the oncall

```
Bridge calls in the middle of the night
waiting for someone to say "restart it"
```


## Access denied

- No access to the production vms

Notes:
- No remote debugger
- No JMX Beans
- Logs, sort of
  - Production Splunk could only support access logs
  - Not helpful at all  