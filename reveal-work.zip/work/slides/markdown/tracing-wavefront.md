## Spring Cloud Sleuth

- Logs with SpanId TraceId
- Tracing with Zipkin or OpenTracing


## Free service included with Spring Boot

[http://localhost:8080/actuator/wavefront](http://localhost:8080/actuator/wavefront)