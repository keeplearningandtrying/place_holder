```
The best person
to create observability
for your application
is you.
```

Notes:
